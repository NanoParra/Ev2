import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage {
  username: string = 'Admin'; // Usuario que inició sesión

  // Lista de alumnos con sus días de faltas inicializados en 0
  alumnos = [
    { nombre: 'Juan Pérez', diasFaltados: 0 },
    { nombre: 'María López', diasFaltados: 0 },
    { nombre: 'Carlos González', diasFaltados: 0 },
    { nombre: 'Ana Fernández', diasFaltados: 0 },
    { nombre: 'Pedro Martínez', diasFaltados: 0 },
    { nombre: 'Lucía Ramírez', diasFaltados: 0 },
    { nombre: 'Jorge Silva', diasFaltados: 0 },
    { nombre: 'Camila Rojas', diasFaltados: 0 },
    { nombre: 'David Torres', diasFaltados: 0 },
    { nombre: 'Daniela Morales', diasFaltados: 0 }
  ];

  constructor() {}

  // Función para agregar una falta al alumno
  agregarFalta(alumno: any) {
    alumno.diasFaltados += 1;
  }
}
